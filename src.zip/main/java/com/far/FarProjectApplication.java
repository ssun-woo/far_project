package com.far;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FarProjectApplication {

	public static void main(String[] args) {
		SpringApplication.run(FarProjectApplication.class, args);
	}

}
