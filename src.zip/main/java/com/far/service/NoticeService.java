package com.far.service;

public interface NoticeService {

}
