package com.far.service;

import com.far.dto.MemberDTO;

public interface LoginService {
	int isexist_mem(MemberDTO memberDTO);
	
}
