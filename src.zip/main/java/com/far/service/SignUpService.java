package com.far.service;

import com.far.dto.MemberDTO;

public interface SignUpService {
	void insertMember(MemberDTO m);
}
