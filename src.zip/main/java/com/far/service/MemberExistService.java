package com.far.service;

public interface MemberExistService {
	int isexist_mem_id(String memId);
}
