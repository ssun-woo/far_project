package com.far.dto;

public class CeoDTO {

	
}
