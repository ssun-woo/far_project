package com.far.dao;

import com.far.dto.JJimDTO;

public interface JJimDAO {

	void setJJim(JJimDTO jdto);

	int getCount(JJimDTO jdto);

	void delJJim(JJimDTO jdto);

}
