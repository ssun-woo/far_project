//package com.far.dao;
//
//import java.util.HashMap;
//
//import com.far.dto.MemberDTO;
//
//public interface FindIdByEmailDAO {
//	public String findIdByEmail(HashMap<String, Object> map);
//}
