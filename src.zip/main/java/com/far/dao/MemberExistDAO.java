package com.far.dao;

public interface MemberExistDAO {
	public int isexist_mem_id(String memId);
	
}
