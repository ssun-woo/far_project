package com.far.dao;

public interface FindMemClassDAO {
	public String findMemClass(String memId);
}
