package com.far.dao;

//@Service
//public class FindIdByEmailDAOImpl implements FindIdByEmailDAO {
//	@Autowired
//	private SqlSession sqlSession;
//	
//	@Override
//	public String findIdByEmail(String memName, String memEmail) {
//		return sqlSession.sele("findIdByEmail",memName, memEmail);
//	}
//	
//}
