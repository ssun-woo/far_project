package com.far.dao;

public interface NoticeDAO {

}
