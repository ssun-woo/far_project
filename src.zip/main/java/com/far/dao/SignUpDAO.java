package com.far.dao;

import com.far.dto.MemberDTO;

public interface SignUpDAO {

	void insertMember(MemberDTO m);
}
