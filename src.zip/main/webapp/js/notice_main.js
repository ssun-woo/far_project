/**
 * notice_main.js
 */
 
