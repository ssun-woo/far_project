/**
 * new_search.js
 */

$(document).ready(function() {
	
});